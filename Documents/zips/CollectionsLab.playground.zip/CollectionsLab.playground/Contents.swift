
// Task 1: Arrays

// Step 1: Create an array of fruits (Atleast 3 elements)


// Step 2: Print the array


// Step 3: Change the second fruit


// Step 4: Add a new fruit


// Step 5: Remove the first fruit




// Task 2: Dictionaries

// Step 1: Create a dictionary with names and ages (Atleast 3 elements)


// Step 2: Print the dictionary


// Step 3: Add a new friend


// Step 4: Update one friend's age


// Step 5: Remove a friend




// Task 3: Sets

// Step 1: Create a set of numbers


// Step 2: Print the set


// Step 3: Try to add a duplicate number


// Step 4: Remove a number

