// Step 1: Define the Book struct
// Add properties here (title, author, publicationYear)

struct Book {
    
}

// Step 2: Create an instance of Book
// Set values for title, author, and publication year

// Step 3: Add a function to the Book struct
// This method should describe the book
func describe() {
    print()
}

// Step 4: Call the describe() function


// Mini Build Challenge: Define the Movie struct and movieInfo function
// Define the Movie struct
// Add properties for title, director, and release year
// Add the movieInfo() function
