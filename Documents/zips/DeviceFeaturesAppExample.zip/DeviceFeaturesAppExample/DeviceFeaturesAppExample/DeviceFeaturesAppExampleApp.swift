//
//  DeviceFeaturesAppExampleApp.swift
//  DeviceFeaturesAppExample
//
//  Created by Noah Carpenter on 2024-12-25.
//

import SwiftUI

@main
struct DeviceFeaturesAppExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
